#!/bin/bash

ES=${ES:-http://localhost:9201}

if ! command -v python3 &> /dev/null; then
  echo "Error: This script requires python3. Please install python3 and try again."
  exit 1
fi

PARENT_DIR=".."

output=$("$PARENT_DIR/list.sh" --es)

mkdir -p .

processing=0
echo "Starting metadata processing..."

while IFS= read -r line; do
  # Check if line starts with "WARNING:" and exit if it does
  if [[ $line == WARNING:* ]]; then
    echo "WARNING detected: $line"
    echo "Processing stopped due to warning."
    exit 1
  fi

  if [[ $processing -eq 0 && $line == *"List elasticsearch indexes"* ]]; then
    processing=1
    continue
  fi

  if [[ $processing -eq 1 && $line == "--------------------------------------------------"* ]]; then
    if [[ $(echo "$line" | grep -c "Finished") -gt 0 ]]; then
      processing=0
      continue
    fi
  fi

  if [[ $processing -eq 1 && $line =~ ^[[:space:]]+([a-zA-Z0-9_]+)[[:space:]]+([a-zA-Z0-9_\.-]+)$ ]]; then
    source="${BASH_REMATCH[1]}"
    version="${BASH_REMATCH[2]}"
    indexVersion=$(echo "$version" | perl -ne 's/[\.\-]//g; print lc($_)')
    output_file="${source}.json"

    echo "Processing: $source version $version (indexVersion: $indexVersion)"
    "$PARENT_DIR/metadata.sh" --noconfig "$source" "$version" "$output_file"

    if [ $? -eq 0 ]; then
      echo "✓ Successfully created $output_file"
    else
      echo "✗ Failed to create $output_file"
    fi

    sleep 2 # Add a 2-second delay

    curl_output=$(curl -s "$ES/evs_metadata/_search?q=indexName:concept_${source}_${indexVersion}")

    fhir_uri=$(echo "$curl_output" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['hits']['hits'][0]['_source']['terminology']['metadata'].get('fhirUri', '') if data.get('hits', {}).get('hits') else '')" 2>/dev/null)
    fhir_publisher=$(echo "$curl_output" | python3 -c "import json, sys; data=json.load(sys.stdin); print(data['hits']['hits'][0]['_source']['terminology']['metadata'].get('fhirPublisher', '') if data.get('hits', {}).get('hits') else '')" 2>/dev/null)

    if [[ -z "$fhir_uri" || -z "$fhir_publisher" ]]; then
        echo "✗ ERROR: $source $indexVersion: fhirUri or fhirPublisher missing or null!"
        echo "  - Available metadata keys:"
        echo "$curl_output" | python3 -c "import json, sys; data=json.load(sys.stdin); [print('    - ' + key) for key in sorted(data['hits']['hits'][0]['_source']['terminology']['metadata'].keys()) if data.get('hits', {}).get('hits')]" 2>/dev/null
        exit 1 # Exit with an error code
    else
        echo "✓ $source $indexVersion: fhirUri and fhirPublisher found."
        echo "  - fhirUri: $fhir_uri"
        echo "  - fhirPublisher: $fhir_publisher"
    fi

    echo "----------------------------------------"
  fi
done <<< "$output"

echo "Metadata processing complete!"

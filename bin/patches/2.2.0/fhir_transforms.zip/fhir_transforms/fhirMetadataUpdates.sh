#!/bin/bash

ES=${ES:-http://localhost:9201}

if ! command -v jq &> /dev/null; then
  echo "Error: This script requires jq. Please install jq and try again."
  exit 1
fi

PARENT_DIR=".."

output=$("$PARENT_DIR/list.sh" --noconfig --es)

mkdir -p .

processing=0
echo "Starting metadata processing..."

while IFS= read -r line; do
  if [[ $processing -eq 0 && $line == *"List elasticsearch indexes"* ]]; then
    processing=1
    continue
  fi

  if [[ $processing -eq 1 && $line == "--------------------------------------------------"* ]]; then
    if [[ $(echo "$line" | grep -c "Finished") -gt 0 ]]; then
      processing=0
      continue
    fi
  fi

  if [[ $processing -eq 1 && $line =~ ^[[:space:]]+([a-zA-Z0-9_]+)[[:space:]]+([a-zA-Z0-9_\.-]+)$ ]]; then
    source="${BASH_REMATCH[1]}"
    version="${BASH_REMATCH[2]}"
    indexVersion=$(echo "$version" | perl -ne 's/[\.\-]//g; print lc($_)')
    output_file="${source}.json"

    echo "Processing: $source version $version (indexVersion: $indexVersion)"
    "$PARENT_DIR/metadata.sh" --noconfig "$source" "$version" "$output_file"

    if [ $? -eq 0 ]; then
      echo "✓ Successfully created $output_file"
    else
      echo "✗ Failed to create $output_file"
    fi

    sleep 2 # Add a 2-second delay

    curl_output=$(curl -s "$ES/evs_metadata/_search?q=indexName:concept_${source}_${indexVersion}")

    fhir_uri=$(echo "$curl_output" | jq -r '.hits.hits[0]._source.terminology.metadata.fhirUri')
    fhir_publisher=$(echo "$curl_output" | jq -r '.hits.hits[0]._source.terminology.metadata.fhirPublisher')

    if [[ -z "$fhir_uri" || -z "$fhir_publisher" ]]; then
        echo "✗ ERROR: $source $indexVersion: fhirUri or fhirPublisher missing or null!"
        echo "  - Available metadata keys:"
        echo "$curl_output" | jq -r '.hits.hits[0]._source.terminology.metadata | keys[]' 2>/dev/null | sort | while read -r key; do
            echo "    - $key"
        done
        exit 1 # Exit with an error code
    else
        echo "✓ $source $indexVersion: fhirUri and fhirPublisher found."
        echo "  - fhirUri: $fhir_uri"
        echo "  - fhirPublisher: $fhir_publisher"
    fi

    echo "----------------------------------------"
  fi
done <<< "$output"

echo "Metadata processing complete!"
